import { ChatModel } from "../../DB/models/index.js";

export const findOrCreateChat = async (userId, providerId) => {
  let chat = await ChatModel.findOne({ userId, providerId });
  if (!chat) {
    chat = await ChatModel.create({ userId, providerId, messages: [] });
  }
  return chat;
};

export const addMessageToChat = async (chatId, message) => {
  return ChatModel.findByIdAndUpdate(
    chatId,
    { $push: { messages: message } },
    { new: true }
  ).populate("userId providerId messages.senderId");
};

export const getUserChats = async (userId) => {
  return ChatModel.find({ userId }).populate("providerId messages.senderId");
};

export const getProviderChats = async (providerId) => {
  return ChatModel.find({ providerId }).populate("userId messages.senderId");
};
